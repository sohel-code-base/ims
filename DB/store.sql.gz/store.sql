-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `category` (`id`, `name`, `status`, `created_at`, `updated_at`, `slug`) VALUES
('c02d131f-df1e-11eb-80f2-bc85562a2f7a',	'Light',	1,	'2021-07-07 18:27:53',	NULL,	'light'),
('c65e178c-df1e-11eb-80f2-bc85562a2f7a',	'PC Switch',	1,	'2021-07-07 18:28:03',	NULL,	'pc-switch');

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customer` (`id`, `name`, `phone`, `address`, `status`, `created_at`, `updated_at`) VALUES
('386e8d8e-df1f-11eb-80f2-bc85562a2f7a',	'Sahin',	'1234',	'Nayanpur',	1,	'2021-07-07 18:31:14',	NULL);

DROP TABLE IF EXISTS `expense`;
CREATE TABLE `expense` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `employee_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `expense_date` date NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2D3A8DA68C03F15C` (`employee_id`),
  CONSTRAINT `FK_2D3A8DA68C03F15C` FOREIGN KEY (`employee_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `expense` (`id`, `employee_id`, `type`, `amount`, `status`, `expense_date`, `created_at`, `updated_at`) VALUES
('2c867185-df1f-11eb-80f2-bc85562a2f7a',	'fc559ee7-df1b-11eb-80f2-bc85562a2f7a',	'Rickshaw',	30,	1,	'2021-07-07',	'2021-07-07 18:30:54',	NULL);

DROP TABLE IF EXISTS `power`;
CREATE TABLE `power` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `watt` int NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `power` (`id`, `watt`, `status`, `created_at`, `updated_at`) VALUES
('db7b18d6-df1e-11eb-80f2-bc85562a2f7a',	5,	1,	'2021-07-07 18:28:38',	NULL),
('de726ed4-df1e-11eb-80f2-bc85562a2f7a',	10,	1,	'2021-07-07 18:28:43',	NULL);

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `sub_category_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D34A04ADF7BFE87C` (`sub_category_id`),
  CONSTRAINT `FK_D34A04ADF7BFE87C` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product` (`id`, `sub_category_id`, `name`, `status`, `created_at`, `updated_at`) VALUES
('f5d6993f-df1e-11eb-80f2-bc85562a2f7a',	'cfd3f869-df1e-11eb-80f2-bc85562a2f7a',	'Color Light',	1,	'2021-07-07 18:29:23',	NULL);

DROP TABLE IF EXISTS `product_purchase`;
CREATE TABLE `product_purchase` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `power_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `quantity` int NOT NULL,
  `purchase_price` int NOT NULL,
  `sale_price` int DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `purchase_date` date NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AAA7BBAC4584665A` (`product_id`),
  KEY `IDX_AAA7BBACAB4FC384` (`power_id`),
  CONSTRAINT `FK_AAA7BBAC4584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK_AAA7BBACAB4FC384` FOREIGN KEY (`power_id`) REFERENCES `power` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_purchase` (`id`, `product_id`, `power_id`, `quantity`, `purchase_price`, `sale_price`, `status`, `purchase_date`, `created_at`, `updated_at`) VALUES
('030723d2-df1f-11eb-80f2-bc85562a2f7a',	'f5d6993f-df1e-11eb-80f2-bc85562a2f7a',	'db7b18d6-df1e-11eb-80f2-bc85562a2f7a',	199,	30,	45,	1,	'2021-07-07',	'2021-07-07 18:29:45',	NULL);

DROP TABLE IF EXISTS `product_purchase_archive`;
CREATE TABLE `product_purchase_archive` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `power_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `quantity` int NOT NULL,
  `purchase_price` double NOT NULL,
  `sale_price` double NOT NULL,
  `purchase_date` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_40AAF3194584665A` (`product_id`),
  KEY `IDX_40AAF319AB4FC384` (`power_id`),
  CONSTRAINT `FK_40AAF3194584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK_40AAF319AB4FC384` FOREIGN KEY (`power_id`) REFERENCES `power` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_purchase_archive` (`id`, `product_id`, `power_id`, `quantity`, `purchase_price`, `sale_price`, `purchase_date`, `status`, `created_at`, `updated_at`) VALUES
('03055fb8-df1f-11eb-80f2-bc85562a2f7a',	'f5d6993f-df1e-11eb-80f2-bc85562a2f7a',	'db7b18d6-df1e-11eb-80f2-bc85562a2f7a',	200,	30,	45,	'2021-07-07',	1,	'2021-07-07',	NULL);

DROP TABLE IF EXISTS `product_sale`;
CREATE TABLE `product_sale` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `employee_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `total_price` double DEFAULT NULL,
  `due_amount` double DEFAULT NULL,
  `sale_date` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_68A3E2A49395C3F3` (`customer_id`),
  KEY `IDX_68A3E2A48C03F15C` (`employee_id`),
  CONSTRAINT `FK_68A3E2A48C03F15C` FOREIGN KEY (`employee_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_68A3E2A49395C3F3` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_sale` (`id`, `customer_id`, `employee_id`, `total_price`, `due_amount`, `sale_date`, `status`, `created_at`, `updated_at`) VALUES
(2,	'386e8d8e-df1f-11eb-80f2-bc85562a2f7a',	'fc559ee7-df1b-11eb-80f2-bc85562a2f7a',	45,	0,	'2021-07-07',	1,	'2021-07-07',	'2021-07-07 18:32:32');

DROP TABLE IF EXISTS `product_sale_details`;
CREATE TABLE `product_sale_details` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `sale_id` int NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `quantity` int NOT NULL,
  `per_pcs_price` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8A9CEB734A7E4868` (`sale_id`),
  KEY `IDX_8A9CEB734584665A` (`product_id`),
  CONSTRAINT `FK_8A9CEB734584665A` FOREIGN KEY (`product_id`) REFERENCES `product_purchase` (`id`),
  CONSTRAINT `FK_8A9CEB734A7E4868` FOREIGN KEY (`sale_id`) REFERENCES `product_sale` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_sale_details` (`id`, `sale_id`, `product_id`, `quantity`, `per_pcs_price`) VALUES
('4b1b34c3-df1f-11eb-80f2-bc85562a2f7a',	2,	'030723d2-df1f-11eb-80f2-bc85562a2f7a',	1,	45);

DROP TABLE IF EXISTS `sub_category`;
CREATE TABLE `sub_category` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `category_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(DC2Type:guid)',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BCE3F79812469DE2` (`category_id`),
  CONSTRAINT `FK_BCE3F79812469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sub_category` (`id`, `category_id`, `name`, `created_at`, `updated_at`, `status`, `slug`) VALUES
('cfd3f869-df1e-11eb-80f2-bc85562a2f7a',	'c02d131f-df1e-11eb-80f2-bc85562a2f7a',	'Color Light',	'2021-07-07 18:28:19',	NULL,	1,	'color-light'),
('d517d9ad-df1e-11eb-80f2-bc85562a2f7a',	'c65e178c-df1e-11eb-80f2-bc85562a2f7a',	'Holder',	'2021-07-07 18:28:28',	NULL,	1,	'holder');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:guid)',
  `username` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `joining_date` date NOT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user` (`id`, `username`, `roles`, `password`, `full_name`, `designation`, `phone`, `signature`, `address`, `status`, `created_at`, `updated_at`, `joining_date`, `photo`, `job_status`) VALUES
('83cd4f9a-0c17-11ec-8709-bc85562a2f7a',	'admin',	'[\"ROLE_ADMIN\"]',	'$argon2id$v=19$m=65536,t=4,p=1$jSU3wOuFMM3ZURSv/r6yrQ$p4lrOE+Hfnrd8fo+f+Zwbt+M4ZZDBszxtulZHCZlOF8',	'Admin',	'Admin',	'123',	NULL,	'Admin Address',	0,	'2021-09-02 23:59:27',	NULL,	'2021-09-02',	'user-avt.png',	0),
('fc559ee7-df1b-11eb-80f2-bc85562a2f7a',	'_sohel',	'[\"ROLE_DEVELOPER\"]',	'$argon2id$v=19$m=65536,t=4,p=1$XH6+sJEu80rEl83rUEH+wQ$xBx26rzWgSCoPOZphrRbrXwyPEHufI4BeLpMuz5hNCQ',	'Md. Sohel Rana',	'Developer',	'01998440363',	'sohel-signature.png',	'Gazipur',	1,	'2021-05-09 22:23:11',	'2021-06-02 21:06:58',	'2021-02-01',	'Md. Sohel Rana-photo.jpg',	1);

-- 2021-09-02 18:18:46
